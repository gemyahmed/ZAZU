import {
  users,
  categories,
  products,
  addresses,
  orders,
  orderItems,
  cartItems,
  frequentOrders,
  frequentOrderItems,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type Product,
  type InsertProduct,
  type ProductWithCategory,
  type Address,
  type InsertAddress,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type CartItem,
  type InsertCartItem,
  type CartItemWithProduct,
  type FrequentOrder,
  type InsertFrequentOrder,
  type FrequentOrderItem,
  type InsertFrequentOrderItem,
  type OrderWithItems,
  type FrequentOrderWithItems,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Product operations
  getProducts(): Promise<ProductWithCategory[]>;
  getProductsByCategory(categoryId: string): Promise<ProductWithCategory[]>;
  getProduct(id: string): Promise<ProductWithCategory | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Address operations
  getUserAddresses(userId: string): Promise<Address[]>;
  createAddress(address: InsertAddress): Promise<Address>;
  updateAddress(id: string, address: Partial<InsertAddress>): Promise<Address>;
  deleteAddress(id: string): Promise<void>;
  
  // Cart operations
  getUserCart(userId: string): Promise<CartItemWithProduct[]>;
  addToCart(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItem(userId: string, productId: string, quantity: number): Promise<CartItem>;
  removeFromCart(userId: string, productId: string): Promise<void>;
  clearCart(userId: string): Promise<void>;
  
  // Order operations
  createOrder(order: InsertOrder): Promise<Order>;
  addOrderItems(orderItems: InsertOrderItem[]): Promise<OrderItem[]>;
  getUserOrders(userId: string): Promise<OrderWithItems[]>;
  getOrder(id: string): Promise<OrderWithItems | undefined>;
  updateOrderStatus(id: string, status: string): Promise<Order>;
  
  // Frequent order operations
  getUserFrequentOrders(userId: string): Promise<FrequentOrderWithItems[]>;
  createFrequentOrder(frequentOrder: InsertFrequentOrder): Promise<FrequentOrder>;
  addFrequentOrderItems(items: InsertFrequentOrderItem[]): Promise<FrequentOrderItem[]>;
  reorderFrequentOrder(userId: string, frequentOrderId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db
      .select()
      .from(categories)
      .where(eq(categories.isActive, true))
      .orderBy(categories.sortOrder);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db
      .insert(categories)
      .values(category)
      .returning();
    return newCategory;
  }

  // Product operations
  async getProducts(): Promise<ProductWithCategory[]> {
    return await db
      .select()
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(and(eq(products.isActive, true), eq(products.inStock, true)))
      .then(rows => rows.map(row => ({
        ...row.products,
        category: row.categories!
      })));
  }

  async getProductsByCategory(categoryId: string): Promise<ProductWithCategory[]> {
    return await db
      .select()
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(and(
        eq(products.categoryId, categoryId),
        eq(products.isActive, true),
        eq(products.inStock, true)
      ))
      .then(rows => rows.map(row => ({
        ...row.products,
        category: row.categories!
      })));
  }

  async getProduct(id: string): Promise<ProductWithCategory | undefined> {
    const [result] = await db
      .select()
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(eq(products.id, id));
    
    if (!result) return undefined;
    
    return {
      ...result.products,
      category: result.categories!
    };
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db
      .insert(products)
      .values(product)
      .returning();
    return newProduct;
  }

  // Address operations
  async getUserAddresses(userId: string): Promise<Address[]> {
    return await db
      .select()
      .from(addresses)
      .where(eq(addresses.userId, userId))
      .orderBy(desc(addresses.isDefault));
  }

  async createAddress(address: InsertAddress): Promise<Address> {
    const [newAddress] = await db
      .insert(addresses)
      .values(address)
      .returning();
    return newAddress;
  }

  async updateAddress(id: string, address: Partial<InsertAddress>): Promise<Address> {
    const [updatedAddress] = await db
      .update(addresses)
      .set(address)
      .where(eq(addresses.id, id))
      .returning();
    return updatedAddress;
  }

  async deleteAddress(id: string): Promise<void> {
    await db.delete(addresses).where(eq(addresses.id, id));
  }

  // Cart operations
  async getUserCart(userId: string): Promise<CartItemWithProduct[]> {
    return await db
      .select()
      .from(cartItems)
      .leftJoin(products, eq(cartItems.productId, products.id))
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(eq(cartItems.userId, userId))
      .then(rows => rows.map(row => ({
        ...row.cart_items,
        product: {
          ...row.products!,
          category: row.categories!
        }
      })));
  }

  async addToCart(cartItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const [existingItem] = await db
      .select()
      .from(cartItems)
      .where(and(
        eq(cartItems.userId, cartItem.userId),
        eq(cartItems.productId, cartItem.productId)
      ));

    if (existingItem) {
      // Update quantity
      const [updatedItem] = await db
        .update(cartItems)
        .set({ 
          quantity: existingItem.quantity + cartItem.quantity,
          updatedAt: new Date()
        })
        .where(eq(cartItems.id, existingItem.id))
        .returning();
      return updatedItem;
    } else {
      // Add new item
      const [newItem] = await db
        .insert(cartItems)
        .values(cartItem)
        .returning();
      return newItem;
    }
  }

  async updateCartItem(userId: string, productId: string, quantity: number): Promise<CartItem> {
    const [updatedItem] = await db
      .update(cartItems)
      .set({ quantity, updatedAt: new Date() })
      .where(and(
        eq(cartItems.userId, userId),
        eq(cartItems.productId, productId)
      ))
      .returning();
    return updatedItem;
  }

  async removeFromCart(userId: string, productId: string): Promise<void> {
    await db
      .delete(cartItems)
      .where(and(
        eq(cartItems.userId, userId),
        eq(cartItems.productId, productId)
      ));
  }

  async clearCart(userId: string): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.userId, userId));
  }

  // Order operations
  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db
      .insert(orders)
      .values(order)
      .returning();
    return newOrder;
  }

  async addOrderItems(orderItems: InsertOrderItem[]): Promise<OrderItem[]> {
    return await db
      .insert(orderItems)
      .values(orderItems)
      .returning();
  }

  async getUserOrders(userId: string): Promise<OrderWithItems[]> {
    const ordersData = await db
      .select()
      .from(orders)
      .leftJoin(addresses, eq(orders.addressId, addresses.id))
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));

    const ordersWithItems: OrderWithItems[] = [];

    for (const orderData of ordersData) {
      const items = await db
        .select()
        .from(orderItems)
        .leftJoin(products, eq(orderItems.productId, products.id))
        .where(eq(orderItems.orderId, orderData.orders.id));

      ordersWithItems.push({
        ...orderData.orders,
        address: orderData.addresses!,
        items: items.map(item => ({
          ...item.order_items,
          product: item.products!
        }))
      });
    }

    return ordersWithItems;
  }

  async getOrder(id: string): Promise<OrderWithItems | undefined> {
    const [orderData] = await db
      .select()
      .from(orders)
      .leftJoin(addresses, eq(orders.addressId, addresses.id))
      .where(eq(orders.id, id));

    if (!orderData) return undefined;

    const items = await db
      .select()
      .from(orderItems)
      .leftJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, id));

    return {
      ...orderData.orders,
      address: orderData.addresses!,
      items: items.map(item => ({
        ...item.order_items,
        product: item.products!
      }))
    };
  }

  async updateOrderStatus(id: string, status: string): Promise<Order> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ status, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  // Frequent order operations
  async getUserFrequentOrders(userId: string): Promise<FrequentOrderWithItems[]> {
    const frequentOrdersData = await db
      .select()
      .from(frequentOrders)
      .where(eq(frequentOrders.userId, userId))
      .orderBy(desc(frequentOrders.lastOrderedAt));

    const ordersWithItems: FrequentOrderWithItems[] = [];

    for (const orderData of frequentOrdersData) {
      const items = await db
        .select()
        .from(frequentOrderItems)
        .leftJoin(products, eq(frequentOrderItems.productId, products.id))
        .where(eq(frequentOrderItems.frequentOrderId, orderData.id));

      ordersWithItems.push({
        ...orderData,
        items: items.map(item => ({
          ...item.frequent_order_items,
          product: item.products!
        }))
      });
    }

    return ordersWithItems;
  }

  async createFrequentOrder(frequentOrder: InsertFrequentOrder): Promise<FrequentOrder> {
    const [newFrequentOrder] = await db
      .insert(frequentOrders)
      .values(frequentOrder)
      .returning();
    return newFrequentOrder;
  }

  async addFrequentOrderItems(items: InsertFrequentOrderItem[]): Promise<FrequentOrderItem[]> {
    return await db
      .insert(frequentOrderItems)
      .values(items)
      .returning();
  }

  async reorderFrequentOrder(userId: string, frequentOrderId: string): Promise<void> {
    // Get frequent order items
    const items = await db
      .select()
      .from(frequentOrderItems)
      .where(eq(frequentOrderItems.frequentOrderId, frequentOrderId));

    // Add to cart
    const cartItemsToAdd: InsertCartItem[] = items.map(item => ({
      userId,
      productId: item.productId,
      quantity: item.quantity
    }));

    for (const cartItem of cartItemsToAdd) {
      await this.addToCart(cartItem);
    }

    // Update last ordered timestamp
    await db
      .update(frequentOrders)
      .set({ lastOrderedAt: new Date() })
      .where(eq(frequentOrders.id, frequentOrderId));
  }
}

export const storage = new DatabaseStorage();
