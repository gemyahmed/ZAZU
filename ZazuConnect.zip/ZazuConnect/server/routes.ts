import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertProductSchema,
  insertCategorySchema,
  insertAddressSchema,
  insertCartItemSchema,
  insertOrderSchema,
  insertOrderItemSchema,
  insertFrequentOrderSchema,
  insertFrequentOrderItemSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Seed initial data
  await seedData();

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Category routes
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Product routes
  app.get('/api/products', async (req, res) => {
    try {
      const { categoryId } = req.query;
      let products;
      
      if (categoryId) {
        products = await storage.getProductsByCategory(categoryId as string);
      } else {
        products = await storage.getProducts();
      }
      
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get('/api/products/:id', async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Address routes
  app.get('/api/addresses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const addresses = await storage.getUserAddresses(userId);
      res.json(addresses);
    } catch (error) {
      console.error("Error fetching addresses:", error);
      res.status(500).json({ message: "Failed to fetch addresses" });
    }
  });

  app.post('/api/addresses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const addressData = insertAddressSchema.parse({ ...req.body, userId });
      const address = await storage.createAddress(addressData);
      res.json(address);
    } catch (error) {
      console.error("Error creating address:", error);
      res.status(500).json({ message: "Failed to create address" });
    }
  });

  // Cart routes
  app.get('/api/cart', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cart = await storage.getUserCart(userId);
      res.json(cart);
    } catch (error) {
      console.error("Error fetching cart:", error);
      res.status(500).json({ message: "Failed to fetch cart" });
    }
  });

  app.post('/api/cart', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cartItemData = insertCartItemSchema.parse({ ...req.body, userId });
      const cartItem = await storage.addToCart(cartItemData);
      res.json(cartItem);
    } catch (error) {
      console.error("Error adding to cart:", error);
      res.status(500).json({ message: "Failed to add to cart" });
    }
  });

  app.put('/api/cart/:productId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { productId } = req.params;
      const { quantity } = req.body;
      
      const cartItem = await storage.updateCartItem(userId, productId, quantity);
      res.json(cartItem);
    } catch (error) {
      console.error("Error updating cart item:", error);
      res.status(500).json({ message: "Failed to update cart item" });
    }
  });

  app.delete('/api/cart/:productId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { productId } = req.params;
      
      await storage.removeFromCart(userId, productId);
      res.json({ message: "Item removed from cart" });
    } catch (error) {
      console.error("Error removing from cart:", error);
      res.status(500).json({ message: "Failed to remove from cart" });
    }
  });

  // Order routes
  app.get('/api/orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const orders = await storage.getUserOrders(userId);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get('/api/orders/:id', isAuthenticated, async (req: any, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post('/api/orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { items, ...orderData } = req.body;
      
      const order = await storage.createOrder({
        ...orderData,
        userId,
        status: 'pending',
        paymentStatus: 'pending'
      });
      
      const orderItems = items.map((item: any) => ({
        orderId: order.id,
        productId: item.productId,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.totalPrice
      }));
      
      await storage.addOrderItems(orderItems);
      
      // Clear cart after successful order
      await storage.clearCart(userId);
      
      res.json(order);
    } catch (error) {
      console.error("Error creating order:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // Frequent orders routes
  app.get('/api/frequent-orders', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const frequentOrders = await storage.getUserFrequentOrders(userId);
      res.json(frequentOrders);
    } catch (error) {
      console.error("Error fetching frequent orders:", error);
      res.status(500).json({ message: "Failed to fetch frequent orders" });
    }
  });

  app.post('/api/frequent-orders/:id/reorder', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      await storage.reorderFrequentOrder(userId, id);
      res.json({ message: "Items added to cart" });
    } catch (error) {
      console.error("Error reordering:", error);
      res.status(500).json({ message: "Failed to reorder" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Seed initial data
async function seedData() {
  try {
    const existingCategories = await storage.getCategories();
    if (existingCategories.length === 0) {
      // Create categories
      const categories = [
        {
          nameAr: "بقالة",
          nameEn: "Grocery",
          description: "أرز، زيوت، معلبات",
          icon: "shopping-basket",
          color: "#2E8B57",
          sortOrder: 1
        },
        {
          nameAr: "خضار وفواكه",
          nameEn: "Fresh Produce",
          description: "طازجة ومحلية",
          icon: "carrot",
          color: "#22C55E",
          sortOrder: 2
        },
        {
          nameAr: "لحوم ودواجن",
          nameEn: "Meat & Poultry",
          description: "طازجة ومجمدة",
          icon: "drumstick-bite",
          color: "#EF4444",
          sortOrder: 3
        },
        {
          nameAr: "مستلزمات منزلية",
          nameEn: "Household",
          description: "منظفات وأدوات",
          icon: "home",
          color: "#3B82F6",
          sortOrder: 4
        }
      ];

      const createdCategories = [];
      for (const category of categories) {
        const created = await storage.createCategory(category);
        createdCategories.push(created);
      }

      // Create sample products
      const products = [
        // Grocery
        {
          categoryId: createdCategories[0].id,
          nameAr: "أرز بسمتي ممتاز",
          nameEn: "Premium Basmati Rice",
          description: "أرز بسمتي فاخر من أجود الأنواع",
          price: "95.00",
          unit: "5 كيلو",
          imageUrl: "https://images.unsplash.com/photo-1586201375761-83865001e31c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
          isFresh: false,
          stockQuantity: 50
        },
        {
          categoryId: createdCategories[0].id,
          nameAr: "زيت عباد الشمس",
          nameEn: "Sunflower Oil",
          description: "زيت عباد الشمس النقي",
          price: "45.00",
          unit: "1 لتر",
          imageUrl: "https://images.unsplash.com/photo-1586201375761-83865001e31c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
          isFresh: false,
          stockQuantity: 30
        },
        // Fresh Produce
        {
          categoryId: createdCategories[1].id,
          nameAr: "خضار مشكلة طازجة",
          nameEn: "Fresh Mixed Vegetables",
          description: "خضار مشكلة طازجة ومحلية",
          price: "45.00",
          originalPrice: "53.00",
          unit: "1 كيلو",
          imageUrl: "https://images.unsplash.com/photo-1610348725531-843dff563e2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
          isFresh: true,
          stockQuantity: 25
        },
        {
          categoryId: createdCategories[1].id,
          nameAr: "فواكه الموسم الطازجة",
          nameEn: "Fresh Seasonal Fruits",
          description: "فواكه الموسم الطازجة والحلوة",
          price: "38.00",
          unit: "1 كيلو",
          imageUrl: "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
          isFresh: true,
          stockQuantity: 20
        },
        // Meat & Poultry
        {
          categoryId: createdCategories[2].id,
          nameAr: "دجاج طازج بلدي",
          nameEn: "Fresh Local Chicken",
          description: "دجاج طازج بلدي عالي الجودة",
          price: "78.00",
          unit: "1 كيلو",
          imageUrl: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
          isFresh: true,
          stockQuantity: 15
        },
        // Household
        {
          categoryId: createdCategories[3].id,
          nameAr: "منظف متعدد الاستخدامات",
          nameEn: "Multi-Purpose Cleaner",
          description: "منظف قوي وآمن للمنزل",
          price: "32.00",
          unit: "1 لتر",
          imageUrl: "https://images.unsplash.com/photo-1585155770941-f302ccf3b2f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
          isFresh: false,
          stockQuantity: 40
        }
      ];

      for (const product of products) {
        await storage.createProduct(product);
      }

      console.log("Initial data seeded successfully");
    }
  } catch (error) {
    console.error("Error seeding data:", error);
  }
}
