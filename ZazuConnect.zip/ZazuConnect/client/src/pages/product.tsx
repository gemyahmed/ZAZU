import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Plus, Minus } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/currency";

export default function Product() {
  const [, params] = useRoute("/product/:id");
  const productId = params?.id;
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery({
    queryKey: ['/api/products', productId],
  });

  const addToCartMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/cart', {
        productId,
        quantity
      });
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة المنتج",
        description: "تم إضافة المنتج إلى السلة بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "لم يتم إضافة المنتج إلى السلة",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="bg-gray-200 rounded-2xl h-64 mb-6"></div>
            <div className="bg-gray-200 rounded h-8 mb-4"></div>
            <div className="bg-gray-200 rounded h-6 w-3/4 mb-2"></div>
            <div className="bg-gray-200 rounded h-6 w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-600">المنتج غير موجود</h1>
          <Link href="/">
            <Button className="mt-4">العودة للرئيسية</Button>
          </Link>
        </div>
      </div>
    );
  }

  const hasDiscount = product.originalPrice && Number(product.originalPrice) > Number(product.price);
  const discountPercent = hasDiscount 
    ? Math.round(((Number(product.originalPrice) - Number(product.price)) / Number(product.originalPrice)) * 100)
    : 0;

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Product Details */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center space-x-4 space-x-reverse mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-gray-600">
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
          <div className="text-sm text-gray-500">
            <Link href="/" className="hover:text-zazu-green">الرئيسية</Link>
            <span className="mx-2">/</span>
            <Link href={`/category/${product.category.id}`} className="hover:text-zazu-green">
              {product.category.nameAr}
            </Link>
            <span className="mx-2">/</span>
            <span className="text-zazu-dark">{product.nameAr}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="relative">
            <img 
              src={product.imageUrl} 
              alt={product.nameAr}
              className="w-full h-96 object-cover rounded-2xl shadow-lg"
            />
            <div className="absolute top-4 right-4 flex flex-col space-y-2">
              {product.isFresh && (
                <Badge className="fresh-badge">
                  طازج
                </Badge>
              )}
              {hasDiscount && (
                <Badge className="discount-badge">
                  خصم {discountPercent}%
                </Badge>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-poppins font-bold text-zazu-dark mb-2">
                {product.nameAr}
              </h1>
              <p className="text-lg text-gray-600 mb-4">{product.unit}</p>
              
              {product.description && (
                <p className="text-gray-600 leading-relaxed">{product.description}</p>
              )}
            </div>

            {/* Price */}
            <div className="flex items-center space-x-4 space-x-reverse">
              <span className="text-3xl font-bold text-zazu-green">
                {formatCurrency(Number(product.price))}
              </span>
              {hasDiscount && (
                <span className="text-xl line-through text-gray-400">
                  {formatCurrency(Number(product.originalPrice))}
                </span>
              )}
            </div>

            {hasDiscount && (
              <div className="bg-orange-50 border border-zazu-orange rounded-xl p-4">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <i className="fas fa-tag text-zazu-orange"></i>
                  <span className="font-semibold text-zazu-dark">
                    توفر {formatCurrency(Number(product.originalPrice) - Number(product.price))}
                  </span>
                </div>
              </div>
            )}

            {/* Stock Status */}
            <div className="flex items-center space-x-2 space-x-reverse">
              {product.inStock ? (
                <>
                  <i className="fas fa-check-circle text-zazu-green"></i>
                  <span className="text-zazu-green font-semibold">متوفر في المخزن</span>
                </>
              ) : (
                <>
                  <i className="fas fa-times-circle text-red-500"></i>
                  <span className="text-red-500 font-semibold">غير متوفر حالياً</span>
                </>
              )}
            </div>

            {/* Quantity Selector */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-zazu-dark">الكمية:</span>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="font-semibold text-lg w-12 text-center">{quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Total Price */}
              <div className="bg-zazu-cream rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-zazu-dark">الإجمالي:</span>
                  <span className="text-2xl font-bold text-zazu-green">
                    {formatCurrency(Number(product.price) * quantity)}
                  </span>
                </div>
              </div>
            </div>

            {/* Add to Cart Button */}
            <Button
              size="lg"
              className="w-full bg-zazu-orange hover:bg-orange-600 text-white py-4 text-lg font-bold"
              onClick={() => addToCartMutation.mutate()}
              disabled={!product.inStock || addToCartMutation.isPending}
            >
              {addToCartMutation.isPending ? (
                <i className="fas fa-spinner fa-spin ml-2"></i>
              ) : (
                <i className="fas fa-shopping-cart ml-2"></i>
              )}
              {product.inStock ? 'أضف إلى السلة' : 'غير متوفر'}
            </Button>

            {/* Quick Suggestions */}
            <div className="border-t pt-6">
              <h4 className="font-semibold text-zazu-dark mb-3">قد يعجبك أيضاً</h4>
              <div className="grid grid-cols-3 gap-3">
                {['ثوم', 'بصل', 'طماطم'].map((item, index) => (
                  <div key={item} className="bg-orange-50 border border-zazu-orange rounded-xl p-3 text-center cursor-pointer hover:bg-orange-100 transition-colors">
                    <i className="fas fa-plus-circle text-zazu-orange mb-2"></i>
                    <p className="text-xs font-semibold text-zazu-dark">{item}</p>
                    <p className="text-xs text-gray-500">{(index + 1) * 8} جنيه</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
