import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowRight } from "lucide-react";
import { Link, useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/currency";

interface Product {
  id: string;
  nameAr: string;
  nameEn: string;
  price: string;
  imageUrl: string;
  unit: string;
}

interface CartItem {
  id: string;
  productId: string;
  quantity: number;
  product: Product;
}

interface Address {
  id: string;
  type: string;
  streetAddress: string;
  area: string;
  city: string;
  buildingDetails?: string;
  isDefault: boolean;
}

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState('cod');

  const { data: cartItems = [] } = useQuery<CartItem[]>({
    queryKey: ['/api/cart'],
  });

  const { data: addresses = [] } = useQuery<Address[]>({
    queryKey: ['/api/addresses'],
  });

  const defaultAddress = addresses.find(addr => addr.isDefault) || addresses[0];

  const subtotal = cartItems.reduce((total, item) => 
    total + (Number(item.product.price) * item.quantity), 0
  );
  const deliveryFee = 0;
  const discount = subtotal > 200 ? 15 : 0;
  const total = subtotal + deliveryFee - discount;

  const createOrderMutation = useMutation({
    mutationFn: async () => {
      if (!defaultAddress) {
        throw new Error("لا يوجد عنوان محدد");
      }

      const orderItems = cartItems.map(item => ({
        productId: item.productId,
        quantity: item.quantity,
        unitPrice: Number(item.product.price),
        totalPrice: Number(item.product.price) * item.quantity
      }));

      const orderData = {
        addressId: defaultAddress.id,
        paymentMethod,
        subtotal: subtotal.toString(),
        deliveryFee: deliveryFee.toString(),
        discount: discount.toString(),
        total: total.toString(),
        estimatedDeliveryTime: new Date(Date.now() + 30 * 60 * 1000), // 30 minutes from now
        items: orderItems
      };

      const response = await apiRequest('POST', '/api/orders', orderData);
      return response.json();
    },
    onSuccess: (order) => {
      toast({
        title: "تم تأكيد الطلب",
        description: `طلب رقم #${order.id.slice(-8)} - ادفع ${formatCurrency(total)} عند الوصول`,
      });
      setLocation(`/order/${order.id}`);
    },
    onError: (error) => {
      toast({
        title: "خطأ في تأكيد الطلب",
        description: error.message || "حدث خطأ غير متوقع",
        variant: "destructive",
      });
    },
  });

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-600 mb-4">سلة التسوق فارغة</h1>
          <Link href="/">
            <Button className="btn-primary">ابدأ التسوق</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center space-x-4 space-x-reverse mb-6">
          <Link href="/cart">
            <Button variant="ghost" size="sm" className="text-gray-600">
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="text-2xl font-poppins font-bold text-zazu-dark">إتمام الطلب</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Cart Items Summary */}
            <Card className="shadow-md">
              <CardContent className="p-6">
                <h3 className="font-poppins font-semibold text-zazu-dark mb-4">تفاصيل الطلب</h3>
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-zazu-cream rounded-xl">
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <img 
                          src={item.product.imageUrl} 
                          alt={item.product.nameAr}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div>
                          <h4 className="font-semibold text-zazu-dark">{item.product.nameAr}</h4>
                          <p className="text-sm text-gray-500">{item.product.unit}</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <span className="font-semibold text-zazu-green">
                          {formatCurrency(Number(item.product.price) * item.quantity)}
                        </span>
                        <p className="text-sm text-gray-500">الكمية: {item.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Delivery Address */}
            <Card className="shadow-md">
              <CardContent className="p-6">
                <h3 className="font-poppins font-semibold text-zazu-dark mb-4">عنوان التوصيل</h3>
                {defaultAddress ? (
                  <div className="bg-zazu-cream rounded-xl p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-zazu-dark">{defaultAddress.type}</h4>
                        <p className="text-gray-600">{defaultAddress.streetAddress}</p>
                        <p className="text-gray-600">{defaultAddress.area}, {defaultAddress.city}</p>
                        {defaultAddress.buildingDetails && (
                          <p className="text-sm text-gray-500">{defaultAddress.buildingDetails}</p>
                        )}
                      </div>
                      <Button variant="ghost" className="text-zazu-green font-semibold">
                        تغيير
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">لم يتم إضافة عنوان بعد</p>
                    <Button className="bg-zazu-green text-white">
                      إضافة عنوان
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Payment Method */}
            <Card className="shadow-md">
              <CardContent className="p-6">
                <h3 className="font-poppins font-semibold text-zazu-dark mb-4">طريقة الدفع</h3>
                
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                  {/* COD Option (Highlighted) */}
                  <div className="zazu-card bg-gradient-to-r from-zazu-orange to-orange-500 border-2 border-zazu-orange p-6 mb-4 text-white relative overflow-hidden">
                    <div className="flex items-center space-x-4 space-x-reverse relative z-10">
                      <RadioGroupItem value="cod" id="cod" className="border-white bg-white" />
                      <Label htmlFor="cod" className="flex items-center space-x-4 space-x-reverse cursor-pointer flex-1">
                        <div className="bg-white bg-opacity-20 rounded-full p-3 backdrop-blur-sm">
                          <i className="fas fa-money-bill-wave text-white text-xl"></i>
                        </div>
                        <div>
                          <h4 className="font-bold text-xl">الدفع عند الاستلام 💰</h4>
                          <p className="text-orange-100">ادفع نقداً عند وصول طلبك - آمن وسهل!</p>
                          <p className="text-white font-semibold mt-1">الخيار المُوصى به ⭐</p>
                        </div>
                      </Label>
                    </div>
                    {/* Decorative elements */}
                    <div className="absolute top-0 right-0 w-20 h-20 bg-white opacity-10 rounded-full -translate-y-10 translate-x-10"></div>
                    <div className="absolute bottom-0 left-0 w-16 h-16 bg-yellow-300 opacity-20 rounded-full translate-y-8 -translate-x-8"></div>
                  </div>
                  
                  {/* Other Payment Methods */}
                  <details className="group">
                    <summary className="flex items-center justify-between p-3 bg-gray-50 rounded-xl cursor-pointer">
                      <span className="text-gray-600">طرق دفع أخرى</span>
                      <i className="fas fa-chevron-down group-open:rotate-180 transition-transform"></i>
                    </summary>
                    <div className="mt-3 space-y-2">
                      <div className="flex items-center space-x-3 space-x-reverse p-3 border rounded-xl">
                        <RadioGroupItem value="card" id="card" />
                        <Label htmlFor="card" className="flex items-center space-x-3 space-x-reverse cursor-pointer flex-1">
                          <i className="fas fa-credit-card text-gray-400"></i>
                          <span>بطاقة ائتمان</span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-3 space-x-reverse p-3 border rounded-xl">
                        <RadioGroupItem value="mobile_wallet" id="mobile_wallet" />
                        <Label htmlFor="mobile_wallet" className="flex items-center space-x-3 space-x-reverse cursor-pointer flex-1">
                          <i className="fas fa-mobile-alt text-gray-400"></i>
                          <span>فودافون كاش</span>
                        </Label>
                      </div>
                    </div>
                  </details>
                </RadioGroup>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card className="shadow-md sticky top-24">
              <CardContent className="p-6">
                <h3 className="font-poppins font-semibold text-zazu-dark mb-4">ملخص الطلب</h3>
                
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between">
                    <span>المجموع الفرعي</span>
                    <span>{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>رسوم التوصيل</span>
                    <span className="text-zazu-green">مجاناً</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-zazu-orange">
                      <span>خصم</span>
                      <span>-{formatCurrency(discount)}</span>
                    </div>
                  )}
                  <div className="border-t pt-3 flex justify-between font-poppins font-bold text-lg">
                    <span>الإجمالي</span>
                    <span className="text-zazu-green">{formatCurrency(total)}</span>
                  </div>
                </div>
                
                <Button
                  className="btn-accent w-full py-4 font-poppins font-bold text-lg"
                  onClick={() => createOrderMutation.mutate()}
                  disabled={!defaultAddress || createOrderMutation.isPending}
                >
                  {createOrderMutation.isPending ? (
                    <i className="fas fa-spinner fa-spin ml-2"></i>
                  ) : (
                    <i className="fas fa-check ml-2"></i>
                  )}
                  اطلب الآن، ادفع عند الوصول! 🚀
                </Button>
                
                <p className="text-center text-sm text-gray-500 mt-3">
                  وقت التوصيل المقدر: 25-30 دقيقة
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
