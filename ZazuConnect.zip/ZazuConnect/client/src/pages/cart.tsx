import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Plus, Minus, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/currency";

export default function Cart() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ['/api/cart'],
  });

  const updateQuantityMutation = useMutation({
    mutationFn: async ({ productId, quantity }: { productId: string; quantity: number }) => {
      await apiRequest('PUT', `/api/cart/${productId}`, { quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "لم يتم تحديث الكمية",
        variant: "destructive",
      });
    },
  });

  const removeItemMutation = useMutation({
    mutationFn: async (productId: string) => {
      await apiRequest('DELETE', `/api/cart/${productId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "تم الحذف",
        description: "تم حذف المنتج من السلة",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "لم يتم حذف المنتج",
        variant: "destructive",
      });
    },
  });

  const subtotal = cartItems.reduce((total, item) => 
    total + (Number(item.product.price) * item.quantity), 0
  );
  const deliveryFee = 0; // Free delivery
  const discount = subtotal > 200 ? 15 : 0; // Example discount logic
  const total = subtotal + deliveryFee - discount;

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-200 rounded-xl h-24"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center space-x-4 space-x-reverse mb-6">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <h1 className="text-2xl font-poppins font-bold text-zazu-dark">سلة التسوق</h1>
          </div>

          <div className="text-center py-16">
            <div className="bg-gray-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-shopping-cart text-gray-400 text-3xl"></i>
            </div>
            <h3 className="text-xl font-poppins font-semibold text-gray-600 mb-2">
              سلة التسوق فارغة
            </h3>
            <p className="text-gray-500 mb-6">ابدأ بإضافة منتجات إلى سلتك</p>
            <Link href="/">
              <Button className="bg-zazu-green text-white">
                ابدأ التسوق
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center space-x-4 space-x-reverse mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-gray-600">
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="text-2xl font-poppins font-bold text-zazu-dark">سلة التسوق</h1>
          <span className="text-gray-500">({cartItems.length} منتج)</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <Card key={item.id} className="shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <img 
                      src={item.product.imageUrl} 
                      alt={item.product.nameAr}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-zazu-dark">{item.product.nameAr}</h3>
                      <p className="text-sm text-gray-500">{item.product.unit}</p>
                      {item.product.isFresh && (
                        <span className="inline-block bg-zazu-green text-white text-xs px-2 py-1 rounded-full mt-1">
                          طازج
                        </span>
                      )}
                    </div>
                    <div className="text-left">
                      <div className="font-semibold text-zazu-green mb-2">
                        {formatCurrency(Number(item.product.price) * item.quantity)}
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantityMutation.mutate({
                            productId: item.productId,
                            quantity: Math.max(1, item.quantity - 1)
                          })}
                          disabled={item.quantity <= 1 || updateQuantityMutation.isPending}
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="font-semibold w-8 text-center">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantityMutation.mutate({
                            productId: item.productId,
                            quantity: item.quantity + 1
                          })}
                          disabled={updateQuantityMutation.isPending}
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeItemMutation.mutate(item.productId)}
                          disabled={removeItemMutation.isPending}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Smart Suggestions */}
            <Card className="shadow-md">
              <CardContent className="p-6">
                <h4 className="font-semibold text-zazu-dark mb-3">أكمل سلتك</h4>
                <div className="grid grid-cols-3 gap-3">
                  {['ثوم', 'بصل', 'طماطم'].map((item, index) => (
                    <div key={item} className="bg-orange-50 border border-zazu-orange rounded-xl p-3 text-center cursor-pointer hover:bg-orange-100 transition-colors">
                      <i className="fas fa-plus-circle text-zazu-orange mb-2"></i>
                      <p className="text-xs font-semibold text-zazu-dark">{item}</p>
                      <p className="text-xs text-gray-500">{(index + 1) * 8} جنيه</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card className="shadow-md sticky top-24">
              <CardContent className="p-6">
                <h3 className="font-poppins font-semibold text-zazu-dark mb-4">ملخص الطلب</h3>
                
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between">
                    <span>المجموع الفرعي</span>
                    <span>{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>رسوم التوصيل</span>
                    <span className="text-zazu-green">مجاناً</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-zazu-orange">
                      <span>خصم</span>
                      <span>-{formatCurrency(discount)}</span>
                    </div>
                  )}
                  <div className="border-t pt-3 flex justify-between font-poppins font-bold text-lg">
                    <span>الإجمالي</span>
                    <span className="text-zazu-green">{formatCurrency(total)}</span>
                  </div>
                </div>
                
                <Link href="/checkout">
                  <Button className="w-full bg-zazu-orange hover:bg-orange-600 text-white py-4 font-poppins font-bold text-lg">
                    متابعة الدفع
                  </Button>
                </Link>
                
                <p className="text-center text-sm text-gray-500 mt-3">
                  وقت التوصيل المقدر: 25-30 دقيقة
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
