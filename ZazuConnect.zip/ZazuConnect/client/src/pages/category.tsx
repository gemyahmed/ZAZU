import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import Header from "@/components/header";
import ProductCard from "@/components/product-card";
import FloatingCart from "@/components/floating-cart";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Category() {
  const [, params] = useRoute("/category/:id");
  const categoryId = params?.id;

  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
  });

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['/api/products', { categoryId: categoryId !== 'all' ? categoryId : undefined }],
  });

  const currentCategory = categories.find(cat => cat.id === categoryId);
  const categoryName = categoryId === 'all' ? 'جميع المنتجات' : currentCategory?.nameAr || '';

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-200 rounded-2xl h-48 mb-4"></div>
                <div className="bg-gray-200 rounded h-4 mb-2"></div>
                <div className="bg-gray-200 rounded h-4 w-3/4"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Category Header */}
      <section className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-gray-600">
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-poppins font-bold text-zazu-dark">{categoryName}</h1>
                <p className="text-gray-600">{products.length} منتج متاح</p>
              </div>
            </div>
            
            {currentCategory && (
              <div className={`w-12 h-12 rounded-full flex items-center justify-center`} 
                   style={{ backgroundColor: `${currentCategory.color}20` }}>
                <i className={`fas fa-${currentCategory.icon} text-xl`} 
                   style={{ color: currentCategory.color }}></i>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {products.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-gray-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-box-open text-gray-400 text-3xl"></i>
            </div>
            <h3 className="text-xl font-poppins font-semibold text-gray-600 mb-2">
              لا توجد منتجات متاحة
            </h3>
            <p className="text-gray-500 mb-6">سيتم إضافة منتجات جديدة قريباً</p>
            <Link href="/">
              <Button className="bg-zazu-green text-white">
                العودة للرئيسية
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

      <FloatingCart />
    </div>
  );
}
