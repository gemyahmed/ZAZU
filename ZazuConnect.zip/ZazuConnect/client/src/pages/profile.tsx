import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/currency";
import { Link } from "wouter";

export default function Profile() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: addresses = [] } = useQuery({
    queryKey: ['/api/addresses'],
  });

  const { data: orders = [] } = useQuery({
    queryKey: ['/api/orders'],
  });

  const { data: frequentOrders = [] } = useQuery({
    queryKey: ['/api/frequent-orders'],
  });

  const recentOrders = orders.slice(0, 3);
  const completedOrders = orders.filter(order => order.status === 'delivered').length;
  const loyaltyPoints = user?.loyaltyPoints || 0;
  const nextLevelPoints = 2000;
  const progressPercentage = Math.min((loyaltyPoints / nextLevelPoints) * 100, 100);

  // Calculate average rating (mock data for now)
  const averageRating = 4.8;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'delivered':
        return <Badge className="bg-zazu-green text-white">تم التوصيل</Badge>;
      case 'out_for_delivery':
        return <Badge className="bg-zazu-orange text-white">في الطريق</Badge>;
      case 'preparing':
        return <Badge className="bg-blue-500 text-white">جاري التحضير</Badge>;
      case 'confirmed':
        return <Badge className="bg-yellow-500 text-white">مؤكد</Badge>;
      case 'cancelled':
        return <Badge className="bg-red-500 text-white">ملغي</Badge>;
      default:
        return <Badge className="bg-gray-500 text-white">غير معروف</Badge>;
    }
  };

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-poppins font-bold text-zazu-dark">حسابي</h1>
          <Button 
            variant="outline" 
            onClick={handleLogout}
            className="text-red-600 border-red-600 hover:bg-red-50"
          >
            تسجيل الخروج
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Overview */}
          <div className="space-y-6">
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <img 
                    src={user?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
                    alt="User profile" 
                    className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="font-poppins font-bold text-zazu-dark">
                    {user?.firstName && user?.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user?.email?.split('@')[0] || 'مستخدم'
                    }
                  </h3>
                  <p className="text-gray-600">
                    عضو منذ {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long' }) : 'فترة قريبة'}
                  </p>
                </div>
                
                {/* Loyalty Points */}
                <div className="bg-gradient-to-r from-zazu-green to-emerald-600 rounded-xl p-4 text-white mb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold">نقاط الولاء</h4>
                      <p className="text-2xl font-bold">{loyaltyPoints.toLocaleString()} نقطة</p>
                    </div>
                    <i className="fas fa-star text-3xl text-yellow-300"></i>
                  </div>
                  <div className="mt-3">
                    <div className="bg-white bg-opacity-20 rounded-full h-2">
                      <div 
                        className="bg-yellow-300 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${progressPercentage}%` }}
                      ></div>
                    </div>
                    <p className="text-sm mt-1 text-emerald-100">
                      {nextLevelPoints - loyaltyPoints} نقطة للمستوى التالي
                    </p>
                  </div>
                </div>
                
                {/* Quick Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-zazu-cream rounded-xl">
                    <div className="text-2xl font-bold text-zazu-green">{completedOrders}</div>
                    <p className="text-sm text-gray-600">طلب مكتمل</p>
                  </div>
                  <div className="text-center p-3 bg-zazu-cream rounded-xl">
                    <div className="text-2xl font-bold text-zazu-orange">{averageRating}</div>
                    <p className="text-sm text-gray-600">تقييم الخدمة</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-md">
              <CardContent className="p-6">
                <h3 className="font-poppins font-semibold text-zazu-dark mb-4">إجراءات سريعة</h3>
                <div className="space-y-3">
                  <Link href="/frequent-orders">
                    <Button variant="outline" className="w-full justify-start">
                      <i className="fas fa-history ml-2"></i>
                      الطلبات المتكررة
                    </Button>
                  </Link>
                  <Link href="/addresses">
                    <Button variant="outline" className="w-full justify-start">
                      <i className="fas fa-map-marker-alt ml-2"></i>
                      إدارة العناوين
                    </Button>
                  </Link>
                  <Link href="/support">
                    <Button variant="outline" className="w-full justify-start">
                      <i className="fas fa-headset ml-2"></i>
                      الدعم الفني
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Address Book */}
          <div className="space-y-6">
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-poppins font-semibold text-zazu-dark">دفتر العناوين</h3>
                  <Button variant="outline" className="text-zazu-green border-zazu-green">
                    إضافة عنوان
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {addresses.length === 0 ? (
                    <div className="text-center py-8">
                      <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                        <i className="fas fa-map-marker-alt text-gray-400 text-xl"></i>
                      </div>
                      <p className="text-gray-500 mb-4">لم يتم إضافة عناوين بعد</p>
                      <Button className="bg-zazu-green text-white">
                        إضافة عنوان جديد
                      </Button>
                    </div>
                  ) : (
                    addresses.map((address) => (
                      <div key={address.id} className={`border rounded-xl p-4 ${
                        address.isDefault ? 'border-zazu-green bg-green-50' : 'border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-zazu-dark flex items-center">
                            <i className={`fas fa-${
                              address.type === 'home' ? 'home' : 
                              address.type === 'work' ? 'briefcase' : 'map-marker-alt'
                            } text-gray-400 ml-2`}></i>
                            {address.type === 'home' ? 'المنزل' : 
                             address.type === 'work' ? 'العمل' : 'أخرى'}
                          </h4>
                          {address.isDefault && (
                            <Badge className="bg-zazu-green text-white">افتراضي</Badge>
                          )}
                        </div>
                        <p className="text-gray-600 text-sm">{address.streetAddress}</p>
                        <p className="text-gray-600 text-sm">{address.area}, {address.city}</p>
                        {address.buildingDetails && (
                          <p className="text-gray-500 text-xs">{address.buildingDetails}</p>
                        )}
                        <div className="flex space-x-2 space-x-reverse mt-2">
                          <Button variant="ghost" size="sm" className="text-zazu-green">
                            تعديل
                          </Button>
                          <Button variant="ghost" size="sm" className="text-gray-500">
                            حذف
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Recent Orders */}
          <div className="space-y-6">
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-poppins font-semibold text-zazu-dark">الطلبات الأخيرة</h3>
                  <Link href="/orders">
                    <Button variant="ghost" className="text-zazu-green font-semibold">
                      عرض الكل
                    </Button>
                  </Link>
                </div>
                
                <div className="space-y-4">
                  {recentOrders.length === 0 ? (
                    <div className="text-center py-8">
                      <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                        <i className="fas fa-shopping-bag text-gray-400 text-xl"></i>
                      </div>
                      <p className="text-gray-500 mb-4">لا توجد طلبات بعد</p>
                      <Link href="/">
                        <Button className="bg-zazu-green text-white">
                          ابدأ التسوق
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    recentOrders.map((order) => (
                      <div key={order.id} className={`border rounded-xl p-4 ${
                        order.status === 'delivered' ? 'border-zazu-green bg-green-50' : 'border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-semibold text-zazu-dark">
                            #{order.id.slice(-8)}
                          </span>
                          {getStatusBadge(order.status)}
                        </div>
                        <p className="text-gray-600 text-sm mb-1">
                          {order.items.slice(0, 2).map(item => item.product.nameAr).join(', ')}
                          {order.items.length > 2 && `... و ${order.items.length - 2} منتج آخر`}
                        </p>
                        <div className="flex justify-between items-center">
                          <span className="text-zazu-green font-semibold">
                            {formatCurrency(Number(order.total))}
                          </span>
                          <span className="text-gray-500 text-xs">
                            {new Date(order.createdAt).toLocaleDateString('ar-EG')}
                          </span>
                        </div>
                        <div className="flex space-x-2 space-x-reverse mt-2">
                          <Link href={`/order/${order.id}`}>
                            <Button variant="ghost" size="sm" className="text-zazu-green">
                              تتبع الطلب
                            </Button>
                          </Link>
                          {order.status === 'delivered' && (
                            <Button variant="ghost" size="sm" className="text-zazu-green">
                              أعد الطلب
                            </Button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
