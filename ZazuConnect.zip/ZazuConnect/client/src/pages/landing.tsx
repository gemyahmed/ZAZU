import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ZazuLogo } from "@/components/zazu-logo";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-zazu-cream to-white">
      {/* Header */}
      <header className="px-4 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <ZazuLogo className="w-12 h-12" animated={true} />
            <h1 className="text-3xl font-poppins font-bold text-zazu-blue">Zazu</h1>
          </div>
          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="btn-accent"
          >
            تسجيل الدخول
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="zazu-card bg-gradient-to-r from-zazu-blue to-blue-700 rounded-full p-8 w-32 h-32 mx-auto mb-8 animate-bounce">
            <i className="fas fa-shipping-fast text-white text-5xl"></i>
          </div>
          
          <h1 className="text-5xl font-poppins font-bold text-zazu-dark mb-6">
            البقالة في لمح البصر
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            احصل على جميع احتياجاتك من البقالة والخضار الطازجة واللحوم في أقل من 30 دقيقة
            <br />
            نخدم بني سويف ومركز الواسطى
          </p>

          <div className="zazu-card bg-gradient-to-r from-zazu-orange to-orange-500 p-6 mb-12 text-white max-w-md mx-auto relative overflow-hidden">
            <div className="flex items-center justify-center space-x-4 space-x-reverse relative z-10">
              <i className="fas fa-clock text-3xl text-white"></i>
              <div>
                <h3 className="text-2xl font-bold">توصيل خلال 30 دقيقة ⚡</h3>
                <p className="text-orange-100">أو أقل!</p>
              </div>
            </div>
            {/* Decorative background elements */}
            <div className="absolute top-0 right-0 w-20 h-20 bg-white opacity-10 rounded-full -translate-y-10 translate-x-10"></div>
            <div className="absolute bottom-0 left-0 w-16 h-16 bg-yellow-300 opacity-20 rounded-full translate-y-8 -translate-x-8"></div>
          </div>

          <Button
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="btn-accent px-12 py-4 text-xl font-bold"
          >
            ابدأ التسوق الآن 🛒
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-poppins font-bold text-center text-zazu-dark mb-12">
            لماذا Zazu؟
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="card-hover">
              <CardContent className="p-8 text-center">
                <div className="bg-zazu-green bg-opacity-10 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <i className="fas fa-leaf text-zazu-green text-3xl"></i>
                </div>
                <h3 className="text-xl font-poppins font-bold text-zazu-dark mb-4">
                  منتجات طازجة
                </h3>
                <p className="text-gray-600">
                  خضار وفواكه ولحوم طازجة يومياً من أفضل المزارع والمصادر المحلية
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-8 text-center">
                <div className="bg-zazu-orange bg-opacity-10 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <i className="fas fa-money-bill-wave text-zazu-orange text-3xl"></i>
                </div>
                <h3 className="text-xl font-poppins font-bold text-zazu-dark mb-4">
                  الدفع عند الاستلام
                </h3>
                <p className="text-gray-600">
                  ادفع نقداً عند وصول طلبك - آمن ومريح ولا حاجة لبطاقات ائتمان
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <CardContent className="p-8 text-center">
                <div className="bg-blue-500 bg-opacity-10 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <i className="fas fa-map-marker-alt text-blue-500 text-3xl"></i>
                </div>
                <h3 className="text-xl font-poppins font-bold text-zazu-dark mb-4">
                  تتبع مباشر
                </h3>
                <p className="text-gray-600">
                  تابع طلبك لحظة بلحظة واعرف موقع عامل التوصيل في الوقت الفعلي
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-3 space-x-reverse mb-4">
            <div className="bg-zazu-green rounded-full p-2">
              <i className="fas fa-bolt text-white text-lg"></i>
            </div>
            <h3 className="text-2xl font-poppins font-bold text-zazu-green">Zazu</h3>
          </div>
          <p className="text-gray-600">
            خدمة توصيل البقالة السريعة في بني سويف ومركز الواسطى
          </p>
          <p className="text-sm text-gray-500 mt-4">
            © 2024 Zazu. جميع الحقوق محفوظة.
          </p>
        </div>
      </footer>
    </div>
  );
}
