import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import Header from "@/components/header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { formatCurrency } from "@/lib/currency";

export default function OrderTracking() {
  const [, params] = useRoute("/order/:id");
  const orderId = params?.id;

  const { data: order, isLoading } = useQuery({
    queryKey: ['/api/orders', orderId],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="bg-gray-200 rounded-2xl h-32 mb-6"></div>
            <div className="bg-gray-200 rounded-2xl h-48 mb-6"></div>
            <div className="bg-gray-200 rounded-2xl h-32"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-600 mb-4">الطلب غير موجود</h1>
          <Link href="/">
            <Button className="bg-zazu-green text-white">العودة للرئيسية</Button>
          </Link>
        </div>
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return 'fas fa-clock';
      case 'confirmed': return 'fas fa-check';
      case 'preparing': return 'fas fa-utensils';
      case 'out_for_delivery': return 'fas fa-shipping-fast';
      case 'delivered': return 'fas fa-home';
      case 'cancelled': return 'fas fa-times';
      default: return 'fas fa-clock';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'في الانتظار';
      case 'confirmed': return 'تم التأكيد';
      case 'preparing': return 'جاري التحضير';
      case 'out_for_delivery': return 'في الطريق';
      case 'delivered': return 'تم التوصيل';
      case 'cancelled': return 'ملغي';
      default: return 'غير معروف';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600';
      case 'confirmed': return 'text-zazu-green';
      case 'preparing': return 'text-blue-600';
      case 'out_for_delivery': return 'text-zazu-orange';
      case 'delivered': return 'text-zazu-green';
      case 'cancelled': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const steps = [
    { key: 'confirmed', label: 'تم الطلب', time: '14:32' },
    { key: 'preparing', label: 'جاري التحضير', time: '14:38' },
    { key: 'out_for_delivery', label: 'في الطريق', time: '14:45' },
    { key: 'delivered', label: 'تم التوصيل', time: '15:05 (متوقع)' }
  ];

  const currentStepIndex = steps.findIndex(step => step.key === order.status);
  const estimatedDeliveryTime = order.estimatedDeliveryTime ? new Date(order.estimatedDeliveryTime) : null;
  const timeRemaining = estimatedDeliveryTime ? Math.max(0, Math.ceil((estimatedDeliveryTime.getTime() - Date.now()) / (1000 * 60))) : 0;

  return (
    <div className="min-h-screen">
      <Header />
      
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center space-x-4 space-x-reverse mb-6">
          <Link href="/profile">
            <Button variant="ghost" size="sm" className="text-gray-600">
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="text-2xl font-poppins font-bold text-zazu-dark">تتبع الطلب</h1>
        </div>

        <div className="space-y-6">
          {/* Order Status Header */}
          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="bg-gradient-to-r from-zazu-green to-emerald-600 rounded-xl p-4 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-poppins font-bold text-xl">طلب رقم #{order.id.slice(-8)}</h3>
                    <p className="text-emerald-100">
                      {order.paymentMethod === 'cod' 
                        ? `ادفع ${formatCurrency(Number(order.total))} عند الوصول` 
                        : `تم دفع ${formatCurrency(Number(order.total))}`
                      }
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl mb-1">
                      <i className={getStatusIcon(order.status)}></i>
                    </div>
                    <p className="text-sm">{getStatusText(order.status)}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Progress Steps */}
          {order.status !== 'cancelled' && (
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="relative mb-8">
                  <div className="flex items-center justify-between">
                    {steps.map((step, index) => (
                      <div key={step.key} className="flex flex-col items-center relative z-10">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white mb-2 ${
                          index <= currentStepIndex ? 'bg-zazu-green' : 
                          index === currentStepIndex + 1 ? 'bg-zazu-orange pulse-animation' : 'bg-gray-300'
                        }`}>
                          {index <= currentStepIndex ? (
                            <i className="fas fa-check text-sm"></i>
                          ) : index === currentStepIndex + 1 ? (
                            <i className={`${getStatusIcon(step.key)} text-sm`}></i>
                          ) : (
                            <i className={`${getStatusIcon(step.key)} text-sm`}></i>
                          )}
                        </div>
                        <p className={`text-sm font-semibold ${
                          index <= currentStepIndex ? 'text-zazu-green' : 
                          index === currentStepIndex + 1 ? 'text-zazu-orange' : 'text-gray-500'
                        }`}>
                          {step.label}
                        </p>
                        <p className="text-xs text-gray-500">{step.time}</p>
                      </div>
                    ))}
                  </div>
                  
                  {/* Progress Line */}
                  <div className="absolute top-4 left-0 right-0 h-0.5 bg-gray-200 z-0">
                    <div 
                      className="h-full bg-zazu-green transition-all duration-1000"
                      style={{ width: `${(currentStepIndex / (steps.length - 1)) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Delivery Agent Info */}
          {order.status === 'out_for_delivery' && order.deliveryAgentName && (
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="bg-zazu-cream rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 space-x-reverse">
                      <img 
                        src="https://images.unsplash.com/photo-1551836022-4c4c79ecde51?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60" 
                        alt="Delivery agent" 
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <h4 className="font-semibold text-zazu-dark">{order.deliveryAgentName}</h4>
                        <p className="text-sm text-gray-600">عامل التوصيل</p>
                        {order.deliveryAgentRating && (
                          <div className="flex items-center mt-1">
                            <div className="flex text-yellow-400">
                              {[...Array(5)].map((_, i) => (
                                <i key={i} className={`fas fa-star text-xs ${
                                  i < Math.floor(Number(order.deliveryAgentRating)) ? '' : 'text-gray-300'
                                }`}></i>
                              ))}
                            </div>
                            <span className="text-xs text-gray-500 mr-2">{order.deliveryAgentRating}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-left">
                      {order.deliveryAgentPhone && (
                        <Button className="bg-zazu-green text-white rounded-full p-3 mb-2">
                          <i className="fas fa-phone"></i>
                        </Button>
                      )}
                      <p className="text-xs text-gray-500">اتصل بالسائق</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* ETA and Map */}
          {order.status === 'out_for_delivery' && timeRemaining > 0 && (
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="bg-gray-100 rounded-xl p-6 text-center">
                  <div className="mb-4">
                    <i className="fas fa-map-marker-alt text-zazu-green text-4xl mb-2"></i>
                    <h4 className="font-poppins font-semibold text-zazu-dark">الوقت المتبقي للوصول</h4>
                    <div className="text-3xl font-bold text-zazu-orange mt-2">{timeRemaining} دقيقة</div>
                    <p className="text-gray-600">تقريباً</p>
                  </div>
                  <div className="bg-white rounded-lg p-4">
                    <p className="text-gray-500">خريطة التتبع المباشر</p>
                    <p className="text-sm text-gray-400">سيتم عرض موقع السائق هنا</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Order Items */}
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h3 className="font-poppins font-semibold text-zazu-dark mb-4">منتجات الطلب</h3>
              <div className="space-y-3">
                {order.items.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-zazu-cream rounded-xl">
                    <div className="flex items-center space-x-3 space-x-reverse">
                      <img 
                        src={item.product.imageUrl || "https://images.unsplash.com/photo-1586201375761-83865001e31c?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
                        alt={item.product.nameAr}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div>
                        <h4 className="font-semibold text-zazu-dark">{item.product.nameAr}</h4>
                        <p className="text-sm text-gray-500">الكمية: {item.quantity}</p>
                      </div>
                    </div>
                    <span className="font-semibold text-zazu-green">
                      {formatCurrency(Number(item.totalPrice))}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="border-t mt-4 pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>المجموع الفرعي</span>
                  <span>{formatCurrency(Number(order.subtotal))}</span>
                </div>
                <div className="flex justify-between">
                  <span>رسوم التوصيل</span>
                  <span className="text-zazu-green">
                    {Number(order.deliveryFee) === 0 ? 'مجاناً' : formatCurrency(Number(order.deliveryFee))}
                  </span>
                </div>
                {Number(order.discount) > 0 && (
                  <div className="flex justify-between text-zazu-orange">
                    <span>خصم</span>
                    <span>-{formatCurrency(Number(order.discount))}</span>
                  </div>
                )}
                <div className="border-t pt-2 flex justify-between font-poppins font-bold text-lg">
                  <span>الإجمالي</span>
                  <span className="text-zazu-green">{formatCurrency(Number(order.total))}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Delivery Address */}
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h3 className="font-poppins font-semibold text-zazu-dark mb-4">عنوان التوصيل</h3>
              <div className="bg-zazu-cream rounded-xl p-4">
                <h4 className="font-semibold text-zazu-dark">{order.address.type}</h4>
                <p className="text-gray-600">{order.address.streetAddress}</p>
                <p className="text-gray-600">{order.address.area}, {order.address.city}</p>
                {order.address.buildingDetails && (
                  <p className="text-sm text-gray-500">{order.address.buildingDetails}</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
