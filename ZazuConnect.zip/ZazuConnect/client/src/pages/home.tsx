import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import CategoryGrid from "@/components/category-grid";
import ProductCard from "@/components/product-card";
import FloatingCart from "@/components/floating-cart";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface Category {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  itemCount: number;
}

interface Product {
  id: string;
  nameAr: string;
  nameEn: string;
  descriptionAr?: string;
  price: string;
  originalPrice?: string;
  imageUrl: string;
  unit: string;
  stockQuantity: number;
  categoryId: string;
}

interface FrequentOrder {
  id: string;
  name: string;
  lastOrderedAt?: string;
  items: Array<{
    id: string;
    product: Product;
    quantity: number;
  }>;
}

interface CartItem {
  id: string;
  quantity: number;
  product: Product;
}

export default function Home() {
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const { data: frequentOrders = [] } = useQuery<FrequentOrder[]>({
    queryKey: ['/api/frequent-orders'],
  });

  const featuredProducts = products.slice(0, 4);

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Delivery Promise Banner */}
          <div className="zazu-card bg-gradient-to-r from-zazu-blue to-blue-700 p-6 mb-6 text-white overflow-hidden relative">
            <div className="flex items-center justify-between relative z-10">
              <div>
                <h2 className="text-xl font-poppins font-bold">توصيل خلال 30 دقيقة ⚡</h2>
                <p className="text-blue-100">في بني سويف ومركز الواسطى</p>
              </div>
              <div className="text-4xl text-zazu-orange animate-bounce">
                <i className="fas fa-shipping-fast"></i>
              </div>
            </div>
            {/* Decorative background elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-zazu-orange opacity-10 rounded-full -translate-y-16 translate-x-16"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white opacity-10 rounded-full translate-y-12 -translate-x-12"></div>
          </div>
          
          {/* Hero Carousel */}
          <div className="relative rounded-2xl overflow-hidden shadow-lg mb-6">
            <img 
              src="https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400" 
              alt="Fresh groceries and shopping" 
              className="w-full h-64 object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <div className="text-center text-white">
                <h3 className="text-3xl font-poppins font-bold mb-2">خضار وفواكه طازجة</h3>
                <p className="text-xl mb-4">خصم 20% على جميع المنتجات الطازجة</p>
                <Link href="/category/fresh">
                  <Button className="btn-accent px-8 py-3 text-lg font-bold">
                    اطلب الآن 🛒
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Category Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-2xl font-poppins font-bold text-zazu-dark mb-6">الأقسام الرئيسية</h2>
        <CategoryGrid categories={categories} />
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-poppins font-bold text-zazu-dark">منتجات مميزة</h2>
          <Link href="/category/all">
            <Button variant="ghost" className="text-zazu-green font-semibold">
              عرض الكل
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Frequent Buys */}
      {frequentOrders.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h2 className="text-2xl font-poppins font-bold text-zazu-dark mb-6">المشتريات المتكررة</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {frequentOrders.slice(0, 2).map((order) => (
              <Card key={order.id} className="shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-poppins font-semibold text-zazu-dark">{order.name}</h3>
                    <span className="text-sm text-gray-500">
                      آخر طلب: {new Date(order.lastOrderedAt || '').toLocaleDateString('ar-EG')}
                    </span>
                  </div>
                  <div className="space-y-2 mb-4">
                    {order.items.slice(0, 3).map((item) => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span>{item.product.nameAr}</span>
                        <span>{Number(item.product.price) * item.quantity} جنيه</span>
                      </div>
                    ))}
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between font-semibold mb-3">
                      <span>الإجمالي</span>
                      <span className="text-zazu-green">
                        {order.items.reduce((total, item) => total + (Number(item.product.price) * item.quantity), 0)} جنيه
                      </span>
                    </div>
                    <Button 
                      className="w-full bg-zazu-green text-white hover:bg-green-700"
                      onClick={() => {
                        // Reorder logic will be handled by the API
                        fetch(`/api/frequent-orders/${order.id}/reorder`, { method: 'POST' })
                          .then(() => window.location.href = '/cart');
                      }}
                    >
                      أعد الطلب
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {/* Add New Frequent Order */}
            <Card className="bg-gradient-to-br from-zazu-orange to-orange-600 text-white shadow-md">
              <CardContent className="p-6 text-center">
                <div className="bg-white bg-opacity-20 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-plus text-2xl"></i>
                </div>
                <h3 className="font-poppins font-semibold mb-2">إنشاء طلب متكرر جديد</h3>
                <p className="text-orange-100 text-sm mb-4">احفظ طلباتك المفضلة لإعادة الطلب بسهولة</p>
                <Button className="bg-white text-zazu-orange hover:bg-orange-50 px-6 py-2 rounded-full font-semibold">
                  ابدأ الآن
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      <FloatingCart />
    </div>
  );
}
