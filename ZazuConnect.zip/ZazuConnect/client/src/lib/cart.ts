import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./queryClient";
import { useToast } from "@/hooks/use-toast";

export function useCart() {
  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ['/api/cart'],
  });

  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  const cartTotal = cartItems.reduce((total, item) => 
    total + (Number(item.product.price) * item.quantity), 0
  );

  return {
    cartItems,
    cartItemCount,
    cartTotal,
    isLoading,
  };
}

export function useAddToCart() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ productId, quantity = 1 }: { productId: string; quantity?: number }) => {
      await apiRequest('POST', '/api/cart', { productId, quantity });
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة المنتج",
        description: "تم إضافة المنتج إلى السلة بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "لم يتم إضافة المنتج إلى السلة",
        variant: "destructive",
      });
    },
  });
}

export function useUpdateCartItem() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ productId, quantity }: { productId: string; quantity: number }) => {
      await apiRequest('PUT', `/api/cart/${productId}`, { quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "لم يتم تحديث الكمية",
        variant: "destructive",
      });
    },
  });
}

export function useRemoveFromCart() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (productId: string) => {
      await apiRequest('DELETE', `/api/cart/${productId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "تم الحذف",
        description: "تم حذف المنتج من السلة",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "لم يتم حذف المنتج",
        variant: "destructive",
      });
    },
  });
}

export function useClearCart() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      // Clear cart by removing all items
      const { data: cartItems } = await queryClient.fetchQuery({
        queryKey: ['/api/cart'],
      });
      
      if (cartItems && cartItems.length > 0) {
        await Promise.all(
          cartItems.map((item: any) => 
            apiRequest('DELETE', `/api/cart/${item.productId}`)
          )
        );
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "تم إفراغ السلة",
        description: "تم حذف جميع المنتجات من السلة",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "لم يتم إفراغ السلة",
        variant: "destructive",
      });
    },
  });
}
