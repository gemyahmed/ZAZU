import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { formatCurrency } from "@/lib/currency";

interface CartItem {
  id: string;
  quantity: number;
  product: {
    id: string;
    nameAr: string;
    price: string;
  };
}

export default function FloatingCart() {
  const { data: cartItems = [] } = useQuery<CartItem[]>({
    queryKey: ['/api/cart'],
  });

  const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
  const totalPrice = cartItems.reduce((total, item) => 
    total + (Number(item.product.price) * item.quantity), 0
  );

  if (totalItems === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 md:left-auto md:right-4 md:max-w-sm">
      <Link href="/cart">
        <div className="zazu-card bg-gradient-to-r from-zazu-orange to-orange-500 text-white p-4 cursor-pointer shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="relative">
                <i className="fas fa-shopping-cart text-2xl"></i>
                <Badge className="absolute -top-2 -right-2 bg-white text-zazu-orange rounded-full text-xs min-w-[1.5rem] h-6 flex items-center justify-center">
                  {totalItems}
                </Badge>
              </div>
              <div>
                <p className="font-semibold">عرض السلة</p>
                <p className="text-sm text-orange-100">{totalItems} منتج</p>
              </div>
            </div>
            <div className="text-left">
              <p className="font-bold text-lg">{formatCurrency(totalPrice)}</p>
              <p className="text-xs text-orange-100">اضغط للمتابعة</p>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}