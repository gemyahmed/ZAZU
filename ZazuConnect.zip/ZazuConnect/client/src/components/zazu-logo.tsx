export function ZazuLogo({ className = "w-8 h-8", animated = false }: { className?: string; animated?: boolean }) {
  return (
    <svg 
      viewBox="0 0 100 100" 
      className={`${className} ${animated ? 'hover:animate-wiggle' : ''}`}
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Bird body - Royal Blue */}
      <ellipse cx="50" cy="65" rx="18" ry="25" fill="#1E3A8A"/>
      
      {/* Bird head - Royal Blue */}
      <circle cx="50" cy="35" r="15" fill="#1E3A8A"/>
      
      {/* Wing details - Lighter blue */}
      <ellipse cx="45" cy="60" rx="8" ry="15" fill="#3B82F6"/>
      <ellipse cx="55" cy="60" rx="8" ry="15" fill="#3B82F6"/>
      
      {/* Beak - Bright Orange */}
      <path d="M35 35 L42 32 L42 38 Z" fill="#FFA500"/>
      
      {/* Eyes */}
      <circle cx="45" cy="30" r="3" fill="white"/>
      <circle cx="55" cy="30" r="3" fill="white"/>
      <circle cx="45" cy="30" r="1.5" fill="black"/>
      <circle cx="55" cy="30" r="1.5" fill="black"/>
      
      {/* Legs - Orange */}
      <rect x="47" y="85" width="2" height="8" fill="#FFA500"/>
      <rect x="51" y="85" width="2" height="8" fill="#FFA500"/>
      
      {/* Feet - Orange */}
      <ellipse cx="48" cy="95" rx="3" ry="1.5" fill="#FFA500"/>
      <ellipse cx="52" cy="95" rx="3" ry="1.5" fill="#FFA500"/>
      
      {/* Decorative feather on head */}
      <path d="M50 20 Q48 15 50 10 Q52 15 50 20" fill="#FFA500"/>
      
      {/* Wing highlights */}
      <ellipse cx="43" cy="55" rx="3" ry="8" fill="#60A5FA" opacity="0.7"/>
      <ellipse cx="57" cy="55" rx="3" ry="8" fill="#60A5FA" opacity="0.7"/>
    </svg>
  );
}