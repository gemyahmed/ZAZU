import { ZazuLogo } from "@/components/zazu-logo";

export default function LoadingScreen() {
  return (
    <div className="min-h-screen bg-zazu-cream flex items-center justify-center">
      <div className="text-center">
        <div className="mb-8">
          <ZazuLogo />
        </div>
        <div className="animate-pulse">
          <div className="h-2 bg-zazu-blue rounded-full w-32 mx-auto mb-4"></div>
          <p className="text-zazu-blue font-semibold text-lg">جاري التحميل...</p>
        </div>
      </div>
    </div>
  );
}