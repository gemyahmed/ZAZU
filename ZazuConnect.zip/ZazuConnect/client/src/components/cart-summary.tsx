import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/currency";
import { Link } from "wouter";

export default function CartSummary() {
  const { data: cartItems = [] } = useQuery({
    queryKey: ['/api/cart'],
  });

  const subtotal = cartItems.reduce((total, item) => 
    total + (Number(item.product.price) * item.quantity), 0
  );
  const deliveryFee = 0; // Free delivery
  const discount = subtotal > 200 ? 15 : 0; // Example discount logic
  const total = subtotal + deliveryFee - discount;

  if (cartItems.length === 0) {
    return null;
  }

  return (
    <Card className="shadow-md sticky top-24">
      <CardContent className="p-6">
        <h3 className="font-poppins font-semibold text-zazu-dark mb-4">ملخص الطلب</h3>
        
        <div className="space-y-3 mb-4">
          <div className="flex justify-between">
            <span>المجموع الفرعي</span>
            <span>{formatCurrency(subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span>رسوم التوصيل</span>
            <span className="text-zazu-green">مجاناً</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-zazu-orange">
              <span>خصم</span>
              <span>-{formatCurrency(discount)}</span>
            </div>
          )}
          <div className="border-t pt-3 flex justify-between font-poppins font-bold text-lg">
            <span>الإجمالي</span>
            <span className="text-zazu-green">{formatCurrency(total)}</span>
          </div>
        </div>
        
        <Link href="/checkout">
          <Button className="w-full bg-zazu-orange hover:bg-orange-600 text-white py-4 font-poppins font-bold text-lg">
            متابعة الدفع
          </Button>
        </Link>
        
        <p className="text-center text-sm text-gray-500 mt-3">
          وقت التوصيل المقدر: 25-30 دقيقة
        </p>
      </CardContent>
    </Card>
  );
}
