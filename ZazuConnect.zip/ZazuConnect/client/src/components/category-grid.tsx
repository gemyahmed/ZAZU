import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";

interface Category {
  id: string;
  nameAr: string;
  nameEn: string;
  icon: string;
  itemCount: number;
}

interface CategoryGridProps {
  categories: Category[];
}

export default function CategoryGrid({ categories }: CategoryGridProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {categories.map((category) => (
        <Link key={category.id} href={`/category/${category.id}`}>
          <Card className="zazu-card cursor-pointer h-full">
            <CardContent className="p-6 text-center">
              <div className="bg-zazu-blue bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <i className={`${category.icon} text-zazu-blue text-2xl`}></i>
              </div>
              <h3 className="font-semibold text-zazu-dark mb-1">{category.nameAr}</h3>
              <p className="text-sm text-gray-500">{category.itemCount} منتج</p>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}