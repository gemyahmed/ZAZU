import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/currency";

interface Product {
  id: string;
  nameAr: string;
  nameEn: string;
  descriptionAr?: string;
  price: string;
  originalPrice?: string;
  imageUrl: string;
  unit: string;
  stockQuantity: number;
  categoryId: string;
}

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addToCartMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/cart/add', {
        productId: product.id,
        quantity
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة المنتج",
        description: `تم إضافة ${product.nameAr} إلى السلة`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: error.message || "حدث خطأ غير متوقع",
        variant: "destructive",
      });
    },
  });

  const hasDiscount = product.originalPrice && Number(product.originalPrice) > Number(product.price);

  return (
    <Card className="zazu-card h-full overflow-hidden">
      <div className="relative">
        <img 
          src={product.imageUrl} 
          alt={product.nameAr}
          className="w-full h-48 object-cover"
        />
        {hasDiscount && (
          <div className="absolute top-2 right-2 bg-zazu-orange text-white px-2 py-1 rounded-full text-sm font-bold">
            خصم
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-zazu-dark mb-2 line-clamp-2">{product.nameAr}</h3>
        
        {product.descriptionAr && (
          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.descriptionAr}</p>
        )}
        
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2 space-x-reverse">
            <span className="font-bold text-zazu-blue">{formatCurrency(Number(product.price))}</span>
            {hasDiscount && (
              <span className="text-sm text-gray-400 line-through">
                {formatCurrency(Number(product.originalPrice))}
              </span>
            )}
          </div>
          <span className="text-sm text-gray-500">{product.unit}</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 space-x-reverse">
            <Button
              variant="outline"
              size="sm"
              className="w-8 h-8 p-0"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
            >
              -
            </Button>
            <span className="w-8 text-center">{quantity}</span>
            <Button
              variant="outline"
              size="sm"
              className="w-8 h-8 p-0"
              onClick={() => setQuantity(quantity + 1)}
            >
              +
            </Button>
          </div>
          
          <Button
            className="btn-accent"
            onClick={() => addToCartMutation.mutate()}
            disabled={addToCartMutation.isPending || product.stockQuantity === 0}
          >
            {addToCartMutation.isPending ? (
              <i className="fas fa-spinner fa-spin"></i>
            ) : (
              <i className="fas fa-plus"></i>
            )}
          </Button>
        </div>
        
        {product.stockQuantity === 0 && (
          <p className="text-sm text-red-500 mt-2 text-center">غير متوفر</p>
        )}
      </CardContent>
    </Card>
  );
}