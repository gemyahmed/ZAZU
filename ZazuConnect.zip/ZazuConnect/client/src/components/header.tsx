import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ZazuLogo } from "@/components/zazu-logo";

interface CartItem {
  id: string;
  quantity: number;
  product: {
    id: string;
    nameAr: string;
    price: string;
  };
}

interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
}

export default function Header() {
  const { user } = useAuth() as { user: User | null };
  const [searchQuery, setSearchQuery] = useState("");

  const { data: cartItems = [] } = useQuery<CartItem[]>({
    queryKey: ['/api/cart'],
  });

  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // TODO: Implement search functionality
      console.log('Search for:', searchQuery);
    }
  };

  const handleVoiceSearch = () => {
    // TODO: Implement voice search
    console.log('Voice search activated');
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-3 space-x-reverse cursor-pointer">
              <ZazuLogo className="w-10 h-10" animated={true} />
              <h1 className="text-2xl font-poppins font-bold text-zazu-blue">Zazu</h1>
            </div>
          </Link>
          
          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-4 search-container">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="ابحث عن منتجاتك..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input w-full text-right pr-12 pl-12"
              />
              <button
                type="submit"
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-zazu-blue hover:text-blue-700 transition-colors"
              >
                <i className="fas fa-search text-lg"></i>
              </button>
              <button
                type="button"
                onClick={handleVoiceSearch}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-zazu-orange hover:text-orange-600 transition-all duration-300 hover:scale-110"
              >
                <i className="fas fa-microphone text-lg"></i>
              </button>
            </form>
          </div>
          
          {/* Cart & Profile */}
          <div className="flex items-center space-x-4 space-x-reverse">
            {/* Cart */}
            <Link href="/cart">
              <div className="relative cursor-pointer">
                <Button className="btn-accent rounded-full p-3 hover:scale-105 transition-all duration-300">
                  <i className="fas fa-shopping-cart"></i>
                </Button>
                {cartItemCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-zazu-blue text-white rounded-full text-xs w-6 h-6 flex items-center justify-center animate-bounce">
                    {cartItemCount > 99 ? '99+' : cartItemCount}
                  </Badge>
                )}
              </div>
            </Link>
            
            {/* Profile */}
            <Link href="/profile">
              <div className="w-10 h-10 bg-gray-300 rounded-full overflow-hidden cursor-pointer">
                <img 
                  src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
