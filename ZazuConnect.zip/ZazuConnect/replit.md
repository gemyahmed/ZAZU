# Zazu - Quick Commerce App

## Overview

Zazu is a comprehensive quick-commerce application designed for Egyptian households, delivering groceries, fresh produce, and household essentials within 30 minutes. The application uses a modern full-stack architecture with React frontend, Express backend, Drizzle ORM for database management, and PostgreSQL as the primary database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom Zazu brand colors (green, orange, cream)
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Icons**: Font Awesome integration

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful endpoints with standardized error handling

### Database Schema
The application uses a comprehensive PostgreSQL schema with the following key entities:
- Users (authentication and profile data)
- Categories (product categorization with Arabic/English names)
- Products (with pricing, inventory, and multilingual support)
- Orders and Order Items (transaction management)
- Cart Items (shopping cart persistence)
- Addresses (delivery locations)
- Frequent Orders (repeat purchase functionality)
- Sessions (authentication state storage)

## Key Components

### Authentication System
- **Provider**: Replit Auth with OIDC
- **Session Storage**: PostgreSQL-backed sessions
- **User Management**: Automatic user creation and profile management
- **Security**: HTTP-only cookies, secure session handling

### Product Catalog
- **Multi-category Support**: Groceries, fresh produce, household essentials
- **Multilingual**: Arabic and English product names
- **Inventory Management**: Stock tracking and availability
- **Pricing**: Support for original/discounted pricing

### Shopping Cart
- **Persistent Storage**: Database-backed cart items
- **Real-time Updates**: TanStack Query for optimistic updates
- **Quantity Management**: Add, update, remove functionality

### Order Management
- **Order Processing**: Complete order lifecycle from cart to delivery
- **Status Tracking**: Multiple order states (pending, confirmed, preparing, etc.)
- **Delivery Integration**: Address management and delivery scheduling

### UI/UX Design
- **Brand Identity**: Complete cartoon-inspired Zazu design with royal blue (#1E3A8A) and bright orange (#FFA500)
- **Responsive Design**: Mobile-first approach with desktop support
- **Arabic Support**: RTL layout considerations and Arabic text with Tajawal font
- **Performance**: Optimized loading states and error handling with custom LoadingScreen component
- **Animations**: Comprehensive cartoon-style hover effects, bounce, pulse, and wiggle animations
- **Payment Focus**: Cash-on-delivery prominently featured with special orange gradient styling
- **Components**: Complete set including animated Zazu logo, floating cart, category grid, product cards

## Data Flow

1. **User Authentication**: Replit Auth → Session Creation → User Profile Setup
2. **Product Discovery**: Category Browse → Product Listing → Product Details
3. **Shopping Flow**: Add to Cart → Cart Management → Checkout Process
4. **Order Processing**: Order Creation → Payment (COD focus) → Order Tracking
5. **Delivery Management**: Address Selection → Delivery Scheduling → Status Updates

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection and query execution
- **drizzle-orm**: Type-safe database operations and schema management
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and developer experience
- **ESBuild**: Production bundling for server code
- **Drizzle Kit**: Database migrations and schema management

### Authentication
- **openid-client**: OIDC authentication flow
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

## Deployment Strategy

### Development Environment
- **Server**: Vite development server with HMR
- **Database**: Neon PostgreSQL instance
- **Authentication**: Replit Auth integration
- **Build Process**: TypeScript compilation with hot reloading

### Production Build
- **Frontend**: Vite build to static assets in `dist/public`
- **Backend**: ESBuild compilation to `dist/index.js`
- **Database**: Drizzle migrations for schema deployment
- **Environment**: Node.js production server with static file serving

### Key Configuration
- **Database URL**: Environment variable for PostgreSQL connection
- **Session Secret**: Secure session encryption key
- **Replit Integration**: Development banner and authentication setup
- **CORS**: Configured for cross-origin requests in development

The application is designed with a focus on cash-on-delivery payments, 30-minute delivery promise, and serves the Beni Suef and Wasty regions in Egypt. The architecture supports rapid scaling and feature additions while maintaining type safety and performance.